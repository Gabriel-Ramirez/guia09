///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package acceso.ws.cliente;
//
//import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.List;
//import javax.faces.bean.ViewScoped;
//import javax.inject.Named;
//import javax.ws.rs.ClientErrorException;
//import javax.ws.rs.client.Client;
//import javax.ws.rs.client.ClientBuilder;
//import javax.ws.rs.client.WebTarget;
//import javax.ws.rs.core.GenericType;
//import javax.ws.rs.core.MediaType;
//
///**
// * Jersey REST client generated for REST resource:TipoPostFacadeREST
// * [tipopost]<br>
// * USAGE:
// * <pre>
// *        TipoPostClase client = new TipoPostClase();
// *        Object response = client.XXX(...);
// *        // do whatever with response
// *        client.close();
// * </pre>
// *
// * @author gabriel
// */
//@Named
//@ViewScoped
//public class TipoPostClase implements Serializable{
//    
//    private Client cliente;
//    private static final String BASE_URI = "http://localhost:8080/Guia08-1.0-SNAPSHOT/webresources/";
//    List<TipoPost> listaUsaurio;
//    private String nombreBuscado;
//
//    public TipoPostCliente() {
//        cliente = ClientBuilder.newClient();
//    }
//
//    public void filtro(){
//        
//        List<TipoPost> salida = null,filtro = new ArrayList<>();
//        if(!nombreBuscado.isEmpty()){
//        try {
//            salida = cliente
//                    .target(BASE_URI)
//                    .path("User")
//                    .request(MediaType.APPLICATION_JSON)
//                    .get(new GenericType<List<TipoPost>>(){});
//            
//            for (Usuario usuario : salida) {
//                if(usuario.getNombres().toLowerCase().matches(".*"+nombreBuscado.toLowerCase()+".*")){
//                    System.out.println(usuario.getNombres());
//                    filtro.add(usuario);
//                }
//            }
//        } catch (Exception e) {
//            System.out.println("ex: "+e);
//        }finally{
//           if(filtro.isEmpty()){
//               filtro = Collections.EMPTY_LIST;
//           }
//        }
//        }
//        listaUsaurio = filtro;
//    }
//    
//    public void mensaje(){
//        System.out.println("ENTRO AQUI ALV PRRO");
//    }
//    
//    public List<Usuario> getListaUsaurio() {
//        return listaUsaurio;
//    }
//
//    public void setListaUsaurio(List<Usuario> listaUsaurio) {
//        this.listaUsaurio = listaUsaurio;
//    }
//
//    public String getNombreBuscado() {
//        return nombreBuscado;
//    }
//
//    public void setNombreBuscado(String nombreBuscado) {
//        this.nombreBuscado = nombreBuscado;
//    }
//    
    
//
//    private WebTarget webTarget;
//    private Client client;
//    private static final String BASE_URI = "http://localhost:8080/guia06/ws";
//    List<WebTarget> listaTipoPost;
//    private String nombreBuscado;
//
//    public TipoPostClase() {
//        try {
//       client = ClientBuilder.newClient();
//        webTarget = client.target(BASE_URI).path("tipopost");  
//        } catch (Exception e) {
//        }
//       
//    }
//
//    public <T> T idTipoPost(Class<T> responseType, String idTipoPost) throws ClientErrorException {
//        WebTarget resource = webTarget;
//        resource = resource.path(java.text.MessageFormat.format("{0}", new Object[]{idTipoPost}));
//        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
//    }

    /*
 Este metodo pide al servidor JSON datos mediante rangos    
    */
//     public <T> T findRange(Class<T> responseType, String pagesize, String first) throws ClientErrorException {
//        try {
//                   
//        WebTarget resource = webTarget;
//        if (pagesize != null) {
//            resource = resource.queryParam("pagesize", pagesize);
//        }
//        if (first != null) {
//            resource = resource.queryParam("first", first);
//        }
//        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
//        } catch (Exception e) {
//        }
//        return (T) new ArrayList();
//    }

     /*
     Este metodo pide al servidor de JSON el numero de datos que se poseen dentro de una determinada entity
     */
//    public <T> T count(Class<T> responseType) throws ClientErrorException {
//        try {
//        WebTarget resource = webTarget;
//        resource = resource.path("count");
//        return resource.request(MediaType.TEXT_PLAIN).get(responseType); 
//        } catch (Exception e) {
//            
//        }
//        return (T) new ArrayList();
//
//    }
//    public void filtro(){
//        
//        List<T> salida = null,filtro = new ArrayList<>();
//        if(!nombreBuscado.isEmpty()){
//        try {
//            salida = cliente
//                    .target(BASE_URI)
//                    .path("tipopost")
//                    .request(MediaType.APPLICATION_JSON)
//                    .get(new GenericType<List<T>>(){});
//            
//            for (TipoPost tipopost : salida) {
//                if(tipopost.getNombres().toLowerCase().matches(".*"+nombreBuscado.toLowerCase()+".*")){
//                    System.out.println(tipopost.getNombres());
//                    filtro.add(tipopost);
//                }
//            }
//        } catch (Exception e) {
//            System.out.println("ex: "+e);
//        }finally{
//           if(filtro.isEmpty()){
//               filtro = Collections.EMPTY_LIST;
//           }
//        }
//        }
//        listaTipoPost = filtro;
//    }
//    public void mensaje(){
//         }
//    
//    public List<TipoPost> getListaTipoPost() {
//        return listaTipoPost;
//    }
//
//    public void setListaTipoPost(List<TipoPost> listaTipoPost) {
//        this.listaTipoPost = listaTipoPost;
//    }
//
//    public String getNombreBuscado() {
//        return nombreBuscado;
//    }
//
//    public void setNombreBuscado(String nombreBuscado) {
//        this.nombreBuscado = nombreBuscado;
//    }
//    
//
//    /*
//    Pide al servidor que le devuelva todos los registros con los que se cuentan
//    */
//    public <T> T findAll(Class<T> responseType) throws ClientErrorException {
//        try {
//        WebTarget resource = webTarget;
//        resource = resource.path("todo");
//        return resource.request(MediaType.APPLICATION_JSON).get(responseType);
//        } catch (Exception e) {
//        }
//      return (T) new ArrayList();
//    }
//
//    public void close() {
//        client.close();
//    }
//    
//}
